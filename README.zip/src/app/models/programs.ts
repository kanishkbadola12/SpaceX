export interface SpacePrograms {
    missionNames: string,
    flightNumbers: number,
    missionIDs: number,
    launchSuccesses: number,
    imageLinks: string,
    launchYear: number
}